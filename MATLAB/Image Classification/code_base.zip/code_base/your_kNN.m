function predict_label = your_kNN(feat)
% Output should be a fixed length vector [num of img, 1]. 
% Please do NOT change the interface.
predict_label = zeros(size(feat,1),1); %dummy. replace it with your own code
end