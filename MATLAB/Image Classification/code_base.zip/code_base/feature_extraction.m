function feat = feature_extraction(img)
% Output should be a fixed length vector [1*dimension] for a single image. 
% Please do NOT change the interface.
feat = rand([1,100]); % dummy, replace this with your algorithm

end